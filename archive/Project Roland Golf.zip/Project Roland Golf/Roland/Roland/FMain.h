#include "playerinput.h"

void PickPlayers();
void LandSatt(int &isp);
void MainEvents(Bools &bo,float &Rhojd,float &RBredd,int x2,int y2,Klubba &klubb,Klubba klubbor[],int &isp,float &value);
void MainSkjut(bool &set,int &x2,int &y2,int &isp,Klubba &klubb,Bools &bo, float &value,Pos &windPos,Pos &WPos);

//struct AllValues
//{
//	bool set;
//	int x2;
//	int y2;
//	int isp;
//	Klubba klubb;
//	Bools bo;
//	float value;
//	float windPos;
//	float WPos;
//};