#include <iostream>
#include "SDL.h"
#include <fstream>
#include <string>
#pragma comment(lib,"SDL.lib")
#pragma comment(lib,"SDLmain.lib")


using namespace std;

SDL_Surface* screen;

void fixing()
{
	while(cin.peek()!='\n')
			cin.get();
}

void DrawIMGAlpha(int x, int y, int w, int h, int x2, int y2, int trans)
{	
  SDL_Surface* img = SDL_LoadBMP("allt.bmp");
 SDL_SetAlpha(img, SDL_SRCALPHA, trans); 

  SDL_Rect dest;
  dest.x = x;
  dest.y = y;
  SDL_Rect dest2;
  dest2.x = x2;
  dest2.y = y2;
  dest2.w = w;
  dest2.h = h;  
    
  SDL_BlitSurface(img, &dest2, screen, &dest);  
  SDL_FreeSurface(img);
}


void DrawIMG(SDL_Surface *img, int x, int y,
                                int w, int h, int x2, int y2)
{	  
  SDL_Rect dest;
  dest.x = x;
  dest.y = y;
  SDL_Rect dest2;
  dest2.x = x2;
  dest2.y = y2;
  dest2.w = w;
  dest2.h = h;      
  SDL_BlitSurface(img, &dest2, screen, &dest);  
}
int hojd1=0,bredd1=0;

int main(int, char**)
{
	bool inladdat=false;
	int bredd;
	int hojd;
	int startX=300;
	int startY=300;

	char loading[5];
	int trans;
	string name;
	ofstream fil;
	ifstream infil;
	string saving;


	//for(int i=0; i<bredd; i++)
	//	for(int j=0; j<hojd; j++)
	//		yta[i][j]=1;

	cout << "Alpha blending strength?(0 - 255)" << endl;
	cin >> trans;	

	cout << "name you want to save it as( level3.map )";
	cin >> saving;

	fixing();
	
	cout << "Load map?(y/n)" << endl;
	cin >> loading;
	fixing();
	

	if(loading[0]=='y' || loading[0]=='Y')
	{				
		cout << "map name: ";
		cin >> name;
		fixing();

		infil.open(name.c_str());
		infil >> bredd >> hojd >> startX >> startY;
		inladdat=true;		
	}
	else
	{				
		cout << "Write the width and height of the map( 50 60 )";
		cin >> bredd >> hojd;		
	}
	cin.get();

	int **yta = new int *[bredd];
	for(int i=0; i<bredd; ++i)
		yta[i]= new int[hojd];

	if(inladdat==true)
	for(int i=0; i<bredd; i++)
		for(int j=0; j<hojd; j++)
			infil >> yta[i][j];
	else
		for(int i=0; i<bredd; i++)
		for(int j=0; j<hojd; j++)
			yta[i][j]=1;

		





	SDL_Init(SDL_INIT_VIDEO);

	screen = SDL_SetVideoMode(800,600,8,SDL_SWSURFACE |SDL_DOUBLEBUF );
	if(! screen)
	{
		cerr << "Error: SetVideoMode failed" << endl;
		SDL_Quit();
		return -1;
	}	

	SDL_Surface* image = SDL_LoadBMP("allt.bmp");
	if(!image)
	{
		cerr << "Error";
		SDL_Quit();
	}

		
	bool done = false; 
	int rotate=0;
	while(!done)
	{
		SDL_Event event;
		while(SDL_PollEvent(&event))
		{
			switch(event.type)
			{
				case SDL_KEYDOWN:
					
					
					switch(event.key.keysym.sym)
					{
					
					case SDLK_r:
					
						rotate+=50;	
						break;
					

					case SDLK_ESCAPE:
					
						done = true;
						break;
					
				
					case SDLK_UP: 
						if(hojd1>0)
						--hojd1;
						break;

					case SDLK_LEFT:
						if(bredd1>0)
						--bredd1;
						break;

					case SDLK_DOWN:
						if(hojd1<(hojd-12))
						++hojd1;
						break;

					case SDLK_RIGHT:
						if(bredd1<(bredd-13))
						++bredd1;	
						break;

					case SDLK_s:
						fil.open(saving.c_str());
						fil << bredd << " " << hojd << " "<< startX << " " << startY<< endl;
						for(int i=0; i<bredd; i++)
						{
							for(int j=0; j<hojd; j++)
								fil << yta[i][j] << " ";
							fil << endl;
						}
						fil.close();
						
					}
					
					break;

				case SDL_QUIT:
					done=true;
				break;
			}
		}
		
		//SDL_BlitSurface(image, 0,screen,0);		

			const int x=55;
		const int a=670;
		const int b=725;
		const int c=30;
		int x2,y2;
	SDL_GetMouseState(&x2,&y2);		
		static int button=1;
		static bool down=false;
	
		
		if(((x2 >=a && x2 < a+50) || (x2 >=b && x2 < b+50)) && 
			(y2 > x-c && y2 < x*7-c+50) && event.type == SDL_MOUSEBUTTONUP && event.button.button == SDL_BUTTON_LEFT)
		{
			if(x2 >=a && x2 < a+50)
			{
				button= ((y2-c)/55)*2+1+rotate%200;				
			}
			else
			{
				button= ((y2-c)/55)*2+2+rotate%200;				
			} 

			rotate=0;
		
		}

	
	if(event.type == SDL_MOUSEBUTTONDOWN )
		if(((x2 < 650 && x2 >1)&& (y2 <649 && y2 > 2))&& event.button.button == SDL_BUTTON_LEFT && event.button.button != SDLK_r ) //l�gger till bild till array
		{
			if(button==14)
			{
				startX=x2+bredd1*50;
				startY=y2+hojd1*50;
			}
			else
				yta[x2/50+bredd1][y2/50+hojd1]=button+rotate%200;
		}
				
		for(int i=1; i<14; ++i)
			for(int j=1; j<13; ++j) //ritar ut allt
			{
				DrawIMG(image, i*50-50, j*50-50, 50, 50, (((50+yta[i-1+bredd1][j-1+hojd1])/50)*50-50), (yta[i-1+bredd1][j-1+hojd1]%50)*50-50);
			}		
		
		DrawIMG(image, a, x-c, 50, 50, 0, 0);
		DrawIMG(image, b, x-c, 50, 50, 0, 50);
		DrawIMG(image, a, x*2-c, 50, 50, 0, 100);
		DrawIMG(image, b, x*2-c, 50, 50, 0, 150);
		DrawIMG(image, a, x*3-c, 50, 50, 0, 200);
		DrawIMG(image, b, x*3-c, 50, 50, 0, 250);
		DrawIMG(image, a, x*4-c, 50, 50, 0, 300);
		DrawIMG(image, b, x*4-c, 50, 50, 0, 350);
		DrawIMG(image, a, x*5-c, 50, 50, 0, 400);
		DrawIMG(image, b, x*5-c, 50, 50, 0, 450);
		DrawIMG(image, a, x*6-c, 50, 50, 0, 500);
		DrawIMG(image, b, x*6-c, 50, 50, 0, 550);
		DrawIMG(image, a, x*7-c, 50, 50, 0, 600);
		DrawIMG(image, b, x*7-c, 50, 50, 0, 650);

		if(((x2 < 650 && x2 >1)&& (y2 <649 && y2 > 2)))					
			DrawIMGAlpha(((50+x2)/50)*50-50,((50+y2)/50)*50-50,50,50,rotate%200,((button*50)/50)*50-50,trans);

		
		
		
		SDL_Flip(screen);
	}

	
	SDL_Quit();

	return 0;
}